# SafeZone

A Pen created on CodePen.io. Original URL: [https://codepen.io/HANURAM-SAGIRAJU-R/pen/NWmmWMP](https://codepen.io/HANURAM-SAGIRAJU-R/pen/NWmmWMP).

